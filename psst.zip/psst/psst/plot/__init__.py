from .plot import plot_stacked_power_generation as stacked_power_generation
from .network import plot_line_power as line_power
