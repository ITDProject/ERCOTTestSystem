/* ============================================================================
 * AMES Wholesale Power Market Test Bed (Java): A Free Open-Source Test-Bed  
 *         for the Agent-based Modeling of Electricity Systems 
 * ============================================================================
 *
 * (C) Copyright 2008, by Hongyan Li, Junjie Sun, and Leigh Tesfatsion
 *
 *    Homepage: http://www.econ.iastate.edu/tesfatsi/AMESMarketHome.htm
 *
 * LICENSING TERMS
 * The AMES Market Package is licensed by the copyright holders (Junjie Sun, 
 * Hongyan Li, and Leigh Tesfatsion) as free open-source software under the       
 * terms of the GNU General Public License (GPL). Anyone who is interested is 
 * allowed to view, modify, and/or improve upon the code used to produce this 
 * package, but any software generated using all or part of this code must be 
 * released as free open-source software in turn. The GNU GPL can be viewed in 
 * its entirety as in the following site: http://www.gnu.org/licenses/gpl.html
 */
// ISO.java
// Independent system operator
package amesmarket;

import java.util.ArrayList;
import java.sql.*;
import java.text.DecimalFormat;
import fncs.JNIfncs;

public class ISO {

    // ISO's data;
    private int currentMonth;   //to check if it has been a month

    private double[][] supplyOfferByGen;
    private double[][] loadProfileByLSE;
    private double[][][] demandBidByLSE;
    private int[][] demandHybridByLSE;
    private double[][] supplyOfferByGenRealTime;
    private double[][] committedLoadByLSERealTime;
    private double[][][] demandBidByLSERealTime;
    private int[][] demandHybridByLSERealTime;
    private double[][] dailyPriceSensitiveDispatch, dailyPriceSensitiveDispatchRT;
    private double[][] dailycommitment, dailyrealtimecommitment, dailyrealtimebranchflow, supplyOfferRT;
    private double[][] dailylmp, dailyrealtimelmp;
    private double[][] dailyBranchFlow;
    private ArrayList commitmentListByDay; // hourly commitments list for each agent by day (d)
    private ArrayList lmpListByDay;        // hourly LMPs list for each bus by day (d)

    private static final int A_INDEX = 0;
    private static final int B_INDEX = 1;
    private static final int CAP_LOWER = 2;
    private static final int CAP_UPPER = 3;

    private AMESMarket ames;
    private DAMarket dam;
    private SRMarket srm;
    private RTMarket rtm;
    private FTRMarket ftrm;
    private BUC buc;
    private int H, I, J, K;

    // constructor
    public ISO(AMESMarket model) {

        //System.out.println("Creating the ISO object: iso \n");
        commitmentListByDay = new ArrayList();
        lmpListByDay = new ArrayList();
        ames = model;
        H = ames.NUM_HOURS_PER_DAY;
        I = ames.getNumGenAgents();
        J = ames.getNumLSEAgents();
        K = ames.getNumNodes();
        supplyOfferRT = new double[I][4];
        dailyPriceSensitiveDispatchRT = new double[H][J];

        dam = new DAMarket(ames);
        srm = new SRMarket(ames);
        rtm = new RTMarket(this, ames);
        ftrm = new FTRMarket(ames);
        buc = new BUC(this, ames);

    }

    public void computeCompetitiveEquilibriumResults() {
        //System.out.println("Compute competitive equilibrium results before the market is run\n");
        dam.submitTrueSupplyOffersAndDemandBids();
        supplyOfferByGen = dam.getTrueSupplyOfferByGen();
        loadProfileByLSE = dam.getLoadProfileByLSE();
        demandBidByLSE = dam.getTrueDemandBidByLSE();
        demandHybridByLSE = dam.getDemandHybridByLSE();

        // Carry out BUC (Bid-based Unit Commitment) problem by solving DC OPF problem
        //System.out.printf("Solving the DC-OPF problem \n");
        buc.solveOPF();

        dailycommitment = buc.getDailyCommitment();
        dailylmp = buc.getDailyLMP();
        dailyPriceSensitiveDispatch = buc.getDailyPriceSensitiveDemand();

        //NOT update generator's commitment, daily lmp, profit
        //dam.post(dailycommitment,dailylmp,1);
        ames.addGenAgentCommitmentWithTrueCost(dailycommitment);
        ames.addLMPWithTrueCost(dailylmp);
        ames.addLSEAgentPriceSensitiveDemandWithTrueCost(dailyPriceSensitiveDispatch);

        dam.postTrueSupplyOfferAndDemandBids(dailycommitment, dailylmp, dailyPriceSensitiveDispatch);
    }

    //newversion
    public void marketOperation(int h, int d) {
        //System.out.println("time_granted: "+ames.getTimeGranted());
        if (h == 1) { // previously h == 0
            dam.dayAheadOperation(h, d);  // fncs.get_events() is called to receive DAM forecast (LSE)
//            if (d != 1) {
//                rtm.realTimeOperation(h, d);
//            }
        }
        
        if (d != 1) {
            if (h == 0) {
                rtm.realTimeOperation(h, d);
            }
            System.out.println("iso.RTMOperation is called at h:" + h);
            evaluateRealTimeBidsOffers(h, d); // fncs.get_events() is called to receive RTM forecast (ISO does it in BUC)
        }

        if (h == 12) {
            System.out.println("iso.dayAheadOperation is called at h:" + h);
            evaluateBidsOffers(h, d);

        }
        if (h == 17) {
            if (d == 321) {
                int stop = 1;
            }
            initialPost(h, d);
            //srm.supplyReOfferOperation(h,d+1,m);
        }
        if (h == 18) {
            //produceCommitmentSchedule(h,d+1,m);
        }

        if (h == 23) {
            forecastLoad();         // Real-time supply over is same as day-ahead supply offer and carry over the price sensitive dispatch to the next day
            // rtm.realTimeOperation(h, d); // Newly added
            if (d != 1) {
                postRealTimeSolutions(h, d);
            }
        }

//        if (d != 1 || (h == 23 && d == 1)) { // added (h == 23 && d ==1) condition
//            evaluateRealTimeBidsOffers(h, d);
//        }
        //rtm.realTimeOperation(h,d,dailycommitmentRT[h],dailyPriceSensitiveDispatch[h]);
    }

    public void forecastLoad() {
        int k;
        for (int i = 0; i < I; i++) {
            for (int j = 0; j < 4; j++) {
                supplyOfferRT[i][j] = supplyOfferByGen[i][j];
            }
        }

        for (int i = 0; i < H; i++) {
            k = 0;
            for (int j = 0; j < J; j++) {
                if (demandHybridByLSE[j][i] == 1) {
                    //System.out.println('h');
                    //System.out.println(J);
                    dailyPriceSensitiveDispatchRT[i][j] = 0;
                    k = k - 1;
                } else {
                    dailyPriceSensitiveDispatchRT[i][j] = dailyPriceSensitiveDispatch[i][k];
                    //System.out.println('I');
                }
                //System.out.println(dailyPriceSensitiveDispatchRT[i][j]);
                //System.out.println(demandHybridByLSE[j][i]);
                k = k + 1;
            }
        }

    }

    public static String getStrings(double[][] a, int index) {
        //String[][] output = new String[a.length][];
        //int i = 0;
        String output = "";
        DecimalFormat LMPFormat = new DecimalFormat("###.####");
        for (int i = 0; i < a.length; i++) {
            //System.out.print( a[i][index]);
            String temp1 = LMPFormat.format(a[i][index]);
            output = output + temp1 + ",";
            //System.out.println("temp.."+temp);
            //output[i++] = Arrays.toString(d).replace("[", "").replace("]", "").split(",");
        }

        //System.out.println();
        return output;
    }

    public void evaluateRealTimeBidsOffers(int h, int d) {

        buc.solveRTOPF(supplyOfferRT, dailyPriceSensitiveDispatchRT[h], h, d);
        dailyrealtimelmp = buc.getDailyRealTimeLMP();
        for (int i = 0; i < I; i++) {
            for (int j = 0; j < 4; j++) {
                //System.out.println("supplyOfferRT: "+supplyOfferRT[i][j]);
            }
            //System.out.println("printing real-time LMP h: " + h + " :" + getStrings(dailyrealtimelmp, i));
        }
    }

    public void postRealTimeSolutions(int h, int d) {
        dailyrealtimecommitment = buc.getDailyRealTimeCommitment();
        dailyrealtimelmp = buc.getDailyRealTimeLMP();
        dailyrealtimebranchflow = buc.getDailyRealTimeBranchFlow();
        ames.addRealTimeLMPByDay(dailyrealtimelmp);
        ames.addGenAgentRealTimeCommitmentByDay(dailyrealtimecommitment);
        ames.addRealTimeBranchFlowByDay(dailyrealtimebranchflow);

//        Connection con = null;
//        Statement stmt = null;
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            String connectionUrl = "jdbc:mysql://" + ames.getHostName() + "/" + ames.getDatabaseName() + "?"
//                    + "user=" + ames.getUserName() + "&password=" + ames.getPassword();
//            con = DriverManager.getConnection(connectionUrl);
//
//            stmt = null;
//            stmt = con.createStatement();
//
//            int i;
//            for (i = 0; i < H; i++) {
//                String strTemp = "INSERT INTO realtimeprice (Identifier,Day,Hour";
//                for (int k = 0; k < K; k++) {
//                    strTemp = strTemp + ",Bus" + (k + 1);
//                }
//                strTemp = strTemp + ") values (" + ((d - 1) * 24 + (i + 1)) + "," + d + "," + i;
//                for (int k = 0; k < K; k++) {
//                    strTemp = strTemp + "," + dailyrealtimelmp[i][k];
//                }
//                strTemp = strTemp + ")";
//
//                stmt.executeUpdate(strTemp);
//
//            }
//
//            stmt.executeUpdate("Update Flag set Flag=" + d + " where type='SimEnd'");
//
//            //for (j=0;j<=2;j++)
//            //System.out.print(hourlyLoadProfileByLSE[j]+" ");
//        } catch (SQLException e) {
//            System.out.println("SQL Exception: " + e.toString());
//        } catch (ClassNotFoundException cE) {
//            System.out.println("Class Not Found Exception: " + cE.toString());
//        } finally {
//            try {
//                if (stmt != null) {
//                    stmt.close();
//                }
//                if (con != null) {
//                    con.close();
//                }
//
//            } catch (SQLException e) {
//                System.out.println("SQL Exception: " + e.toString());
//            }
//        }
    }

    public void evaluateBidsOffers(int h, int d) {
        //System.out.println("Hour " + h + " Day " + d  +
        //                   ": Evaluate LSEs' bids and GenCos' offers.");

        supplyOfferByGen = dam.getSupplyOfferByGen();
        //System.out.println("SupplyOffer b is "+supplyOfferByGen[0][1]);
        loadProfileByLSE = dam.getLoadProfileByLSE();
        demandBidByLSE = dam.getDemandBidByLSE();
        demandHybridByLSE = dam.getDemandHybridByLSE();

        // Carry out BUC (Bid-based Unit Commitment) problem by solving DC OPF problem
        //System.out.printf("Solving the DC-OPF problem for day %1$d \n", d+1);
        buc.solveOPF();
        //Realtime OPF

        dailycommitment = buc.getDailyCommitment();  //dailycommittment -> damcommittment
        //System.out.println("Pls check is "+dailycommitment[0][1]);
        dailylmp = buc.getDailyLMP();  //dailylmp -> damlmps
        dailyBranchFlow = buc.getDailyBranchFlow(); //dailybranchflow -> dambranchflow
        dailyPriceSensitiveDispatch = buc.getDailyPriceSensitiveDemand();

        ames.addLSEAgenPriceSensitiveDemandByDay(dailyPriceSensitiveDispatch);
        ames.addBranchFlowByDay(dailyBranchFlow);
        ames.addGenAgentCommitmentByDay(dailycommitment);
        ames.addLMPByDay(dailylmp);
        ames.addHasSolutionByDay(buc.getHasSolution());
    }

    public void initialPost(int h, int d) {
        //System.out.println("Hour " + h + " Day " + d +
        //                   ": Post hourly commitment schedule and hourly LMPs.");

        dam.post(dailycommitment, dailylmp, dailyPriceSensitiveDispatch, 2);

//        Connection con = null;
//        Statement stmt = null;
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            String connectionUrl = "jdbc:mysql://" + ames.getHostName() + "/" + ames.getDatabaseName() + "?"
//                    + "user=" + ames.getUserName() + "&password=" + ames.getPassword();
//            con = DriverManager.getConnection(connectionUrl);
//
//            stmt = con.createStatement();
//
//            int i;
//            for (i = 0; i <= 23; i++) {
//                String strTemp = "INSERT INTO price (Identifier,Day,Hour";
//                for (int k = 0; k < K; k++) {
//                    strTemp = strTemp + ",Bus" + (k + 1);
//                }
//                strTemp = strTemp + ") values (" + ((d - 1) * 24 + (i + 1)) + "," + d + "," + i;
//                for (int k = 0; k < K; k++) {
//                    strTemp = strTemp + "," + dailylmp[i][k];
//                }
//                strTemp = strTemp + ")";
//
//                stmt.executeUpdate(strTemp);
//            }
//
//            stmt.executeUpdate("Update Flag set Flag=1 where type='Java'");
//
//        } catch (SQLException e) {
//            System.out.println("SQL Exception: " + e.toString());
//        } catch (ClassNotFoundException cE) {
//            System.out.println("Class Not Found Exception: " + cE.toString());
//        } finally {
//            try {
//                if (stmt != null) {
//                    stmt.close();
//                }
//                if (con != null) {
//                    con.close();
//                }
//
//            } catch (SQLException e) {
//                System.out.println("SQL Exception: " + e.toString());
//            }
//        }
    }

    public void produceCommitmentSchedule(int h, int d) {
        System.out.println("Hour " + h + " Day " + d
                + ": produce commitment schedule.");
    }

    public void DayAheadMarketCheckLastDayAction() {
        dam.checkGenLastDayAction();
    }

    // Get and set method
    public double[][] getSupplyOfferByGen() {
        return supplyOfferByGen;
    }

    public double[][] getLoadProfileByLSE() {
        return loadProfileByLSE;
    }

    public double[][][] getDemandBidByLSE() {
        return demandBidByLSE;
    }

    public int[][] getDemandHybridByLSE() {
        return demandHybridByLSE;
    }

    public double[][] getSupplyOfferByGenRT() {
        return supplyOfferRT;
    }

    public double[][] getPriceSensitiveDispatchRT() {
        return dailyPriceSensitiveDispatch;
    }

    public int[][] getRealTimeDemandHybridByLSE() {
        return demandHybridByLSERealTime;
    }

    public DAMarket getDAMarket() {
        return dam;
    }

    public SRMarket getSRMarket() {
        return srm;
    }

    public RTMarket getRTMarket() {
        return rtm;
    }

    public FTRMarket getFTRMarket() {
        return ftrm;
    }

    public BUC getBUC() {
        return buc;
    }

    public double[][] getDailyLMP() {
        return buc.getDailyLMP();
    }

    public double[][] getDailyRealTimeLMP() {
        return buc.getDailyRealTimeLMP();
    }

}
